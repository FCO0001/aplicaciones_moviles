package com.example.iniciarsesion;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

public class RegistrarUsuario extends AppCompatActivity {

    private EditText UsernameReal;
    private EditText IngresoUsername;
    private EditText IngresoPassword;
    private EditText IngresoCorreo;
    private Button botonRegistro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registrar_usuario);

        UsernameReal = findViewById(R.id.nombre_real);
        IngresoUsername = findViewById(R.id.nombre_usuario);
        IngresoPassword = findViewById(R.id.contraseña);
        IngresoCorreo = findViewById(R.id.CorreoElectronico);
        botonRegistro = findViewById(R.id.btnRegistrate);

        botonRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Obtener los valores de los EditText
                String nombreReal = UsernameReal.getText().toString();
                String username = IngresoUsername.getText().toString();
                String password = IngresoPassword.getText().toString();
                String correo = IngresoCorreo.getText().toString();

                if (!nombreReal.isEmpty() && !username.isEmpty() && !password.isEmpty() && !correo.isEmpty()) {
                    // Aquí deberías añadir la lógica para registrar al usuario en tu backend o base de datos
                    Toast.makeText(RegistrarUsuario.this, "Usuario registrado con éxito", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(RegistrarUsuario.this, Login.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(RegistrarUsuario.this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
