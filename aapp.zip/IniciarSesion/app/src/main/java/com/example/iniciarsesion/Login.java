package com.example.iniciarsesion;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

public class Login extends AppCompatActivity {

    private EditText Username;
    private EditText Password;
    private Button buttonLogin;
    private Button buttonIrRegistro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        Username = findViewById(R.id.entradaUsuario);
        Password = findViewById(R.id.entradaContraseña);
        buttonLogin = findViewById(R.id.btnIngresarlogin);
        buttonIrRegistro = findViewById(R.id.btnIrRegistrate);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = Username.getText().toString();
                String password = Password.getText().toString();

                if(username.equals("admin") && password.equals("adminadmin")) {
                    // Correct credentials, proceed to the main screen
                    Intent intent = new Intent(Login.this, Menu.class); // Assuming Menu is your main screen
                    startActivity(intent);
                    finish(); // Close the login screen so it's not reachable via back button
                } else {
                    // Incorrect credentials
                    Toast.makeText(Login.this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonIrRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Go to the registration screen
                Intent intent = new Intent(Login.this, RegistrarUsuario.class); // Assuming RegistrarUsuario is your registration screen
                startActivity(intent);
            }
        });
    }
}
