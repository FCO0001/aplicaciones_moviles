package com.example.iniciarsesion;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class HistorialAcciones extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.historial_acciones);
    }
}