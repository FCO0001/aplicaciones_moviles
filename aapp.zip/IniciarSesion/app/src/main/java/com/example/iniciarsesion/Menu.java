package com.example.iniciarsesion;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;


public class Menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu);


        // Botón para el emparejamiento de dispositivos
        Button btnEmparejamiento = findViewById(R.id.btnEmparejamiento);
        btnEmparejamiento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Menu.this, com.example.iniciarsesion.EmparejamientoDispositivosRegistroNombre.class);
                startActivity(intent);
            }
        });



        // Botón para el control de dispositivos
        Button btnControlDispositivos = findViewById(R.id.btnControl_dispositivos);
        btnControlDispositivos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Menu.this, com.example.iniciarsesion.ControlDispositivos.class);
                startActivity(intent);
            }
        });

        // Botón para ver el historial de acciones
        Button btnHistorialAcciones = findViewById(R.id.btnHistorial_acciones);
        btnHistorialAcciones.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Menu.this, com.example.iniciarsesion.HistorialAcciones.class);
                startActivity(intent);
            }
        });

        // Botón para cerrar sesión
        Button btnCerrarSesion = findViewById(R.id.btnCerrar_sesion);
        btnCerrarSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Menu.this, com.example.iniciarsesion.CerrarSesion.class);
                startActivity(intent);
            }
        });

        // Botón para eliminar cuenta
        Button btnEliminarCuenta = findViewById(R.id.btnEliminar_cuenta);
        btnEliminarCuenta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Menu.this, com.example.iniciarsesion.EliminacionRegistroCuenta.class);
                startActivity(intent);
            }
        });


    }
}